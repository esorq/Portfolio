# Pneumonia > 2023-01-17 11:54am
https://universe.roboflow.com/erik-sorqvist/pneumonia-tzsk8

Provided by a Roboflow user
License: CC BY 4.0

