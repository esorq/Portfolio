# Pneumonia > 2023-01-18 9:00am
https://universe.roboflow.com/classification/pneumonia-tzsk8

Provided by a Roboflow user
License: CC BY 4.0

